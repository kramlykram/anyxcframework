//
//  NewkyCardScanner.h
//  NewkyCardScanner
//
//  Created by Bedirhan Turhan on 6.01.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for NewkyCardScanner.
FOUNDATION_EXPORT double NewkyCardScannerVersionNumber;

//! Project version string for NewkyCardScanner.
FOUNDATION_EXPORT const unsigned char NewkyCardScannerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NewkyCardScanner/PublicHeader.h>


